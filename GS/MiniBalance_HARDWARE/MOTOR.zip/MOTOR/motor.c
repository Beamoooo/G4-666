/***********************************************
公司：WHEELTEC 智能机器人东莞有限公司
品牌：WHEELTEC
网站：wheeltec.net
淘宝店铺：shop114407458.taobao.com 
AliExpress: https://minibalance.aliexpress.com/store/4455017
版本：1.0
修改时间：2024-12-23

Brand: WHEELTEC
Website: wheeltec.net
Taobao shop: shop114407458.taobao.com 
Aliexpress: https://minibalance.aliexpress.com/store/4455017
Version: 1.0
Update: 2024-12-23

All rights reserved
***********************************************/
#include "motor.h"

/**************************************************************************
Function: Initialize Motor Interface
Input   : none
Output  : none
功能说明：初始化电机接口
入口参数：无
返回值  ：无
**************************************************************************/
void MiniBalance_Motor_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // 初始化PA4、PA5和PA7作为方向控制输出
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 先設置電機為停止狀態（在使能STBY之前）
    AIN1 = 0;
    AIN2 = 0;
    
    // 初始化PB0作为PWM输出
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // 最後設置STBY為高電平（使能驅動板）
    STBY = 1;
}

/**************************************************************************
Function: Initialize PWM to drive motor
Input   : arr - Auto reload value, psc - Prescaler coefficient
Output  : none
功能说明：初始化PWM来驱动电机 
入口参数：arr - 自动重装值，psc - 预分频系数
返回值  ：无
**************************************************************************/
void MiniBalance_PWM_Init(u16 arr,u16 psc)
{		 		
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    
    // 初始化电机接口
    MiniBalance_Motor_Init();
    
    // 使能TIM3时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    
    // 配置TIM3通道3（PB0）为PWM输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // 配置TIM3
    TIM_TimeBaseStructure.TIM_Period = arr;
    TIM_TimeBaseStructure.TIM_Prescaler = psc;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
    
    // 配置TIM3通道3为PWM模式
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC3Init(TIM3, &TIM_OCInitStructure);
    
    // 使能TIM3
    TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM3, ENABLE);
    TIM_Cmd(TIM3, ENABLE);
}
