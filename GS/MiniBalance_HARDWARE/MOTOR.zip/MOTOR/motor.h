/***********************************************
��˾����Ȥ�Ƽ�����ݸ�����޹�˾
Ʒ�ƣ�WHEELTEC
������wheeltec.net
�Ա����̣�shop114407458.taobao.com 
����ͨ: https://minibalance.aliexpress.com/store/4455017
�汾��5.7
�޸�ʱ�䣺2021-04-29

 
Brand: WHEELTEC
Website: wheeltec.net
Taobao shop: shop114407458.taobao.com 
Aliexpress: https://minibalance.aliexpress.com/store/4455017
Version:5.7
Update��2021-04-29

All rights reserved
***********************************************/
#ifndef __MOTOR_H
#define __MOTOR_H
#include <sys.h>	 
// TB6612FNG驅動板配置（實際接線）
#define PWMA   TIM3->CCR3  //PB0 - 電機A的PWM（TIM3_CH3）
#define AIN1   PAout(4)    //PA4 - 電機A方向控制1
#define AIN2   PAout(5)    //PA5 - 電機A方向控制2
#define STBY   PAout(7)    //PA7 - 工作/待機控制（必須為高電平）

// 保留原定義以兼容舊代碼
#define PWMB   TIM3->CCR1  //PB0
#define BIN2   PAout(4)    //PA4
#define BIN1   PAout(5)    //PA5
#define PWMA_OLD   TIM1->CCR1  //PA8

void MiniBalance_PWM_Init(u16 arr,u16 psc);
void MiniBalance_Motor_Init(void);
#endif
